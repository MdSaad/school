<!DOCTYPE html>
<html lang="en">
  

  <head>
    
    <title>Caution</title>
   
  </head>
  <body> 
	<div style=" width:1200px; height:1000px; background-color:#999999; margin: auto; color:#FFFFFF; position:relative;" >
	
	<div style=" width:1200px; height:1000px; background-color:#999999; margin: auto; color:#FFFFFF; position: absolute;" >
	 <p>
	 <h1 style="text-align:center; margin-top:100px;">CAUTION !!!!</h1>
	 </p>
	 
					 <p>
					 <h1 style="text-align:center; margin-top:100px;">This is Software Auto Create System Lock !!!!</h1>
					 <h1 style="text-align:center; ">Please Contact With Usoftbd Billing System !!!!</h1>
					 <h1 style=" margin-left:680px;">01795 600 300 !!!!</h1>
					 
					 </p>
	 </div>
	</div>
   
  </body>


</html>

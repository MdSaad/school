
<table width="100%" border="0" cellspacing="0" cellpadding="0" class="table-responsive table-condensed img-thumbnail">
 <tbody style="width:100%; display:block">
  <tr style="width:100%;display: block;">
    <td colspan="6" align="center" valign="middle" style="width:100%;display: block; margin-top: 10px;"><strong style="font-size:20px; text-decoration:underline">Employee Basic Information </strong> </td>
  </tr>
  <tr style="width:100%; display:block">
    <td colspan="6" style="padding-left: 25px; width:100%; display:block">
	 <table width="100%" border="0" style="line-height:30px; width:100%;">
	  <tr>
		<td width="24%" align="left" valign="middle"><strong>Domain Name</strong></td>
		<td width="3%" align="center" valign="middle"><strong>:</strong></td>
		<td width="23%" align="left" valign="middle"><?php echo $empBasicReportData->domain_name ?></td>
		<td width="20%" align="left" valign="middle"><strong>Id</strong></td>
		<td width="3%" align="center" valign="middle"><strong>:</strong></td> 
		<td width="27%" align="left" valign="middle"><?php echo $empBasicReportData->employee_id ?></td>
	  </tr>
	  <tr>
		<td align="left" valign="middle"><strong>Employee Name </strong></td>
		<td align="center" valign="middle"><strong>:</strong></td>
		<td align="left" valign="middle"><?php echo $empBasicReportData->employee_full_name ?></td>
		<td align="left" valign="middle"><strong>Marital Status</strong></td>
		<td align="center" valign="middle"><strong>:</strong></td>
		<td align="left" valign="middle"><?php echo $empBasicReportData->maritus_status ?></td>
	  </tr>
	  <tr>
		<td align="left" valign="middle"><strong>Father's Name</strong></td>
		<td align="center" valign="middle"><strong>:</strong></td>
		<td align="left" valign="middle"><?php echo $empBasicReportData->father_name ?></td>
		<td align="left" valign="middle"><strong>Gender</strong></td>
		<td align="center" valign="middle">:</td>
		<td align="left" valign="middle"><?php echo $empBasicReportData->gender ?></td>
	  </tr>
	  <tr>
		<td align="left" valign="middle"><strong>Mother's Name</strong></td>
		<td align="center" valign="middle"><strong>:</strong></td>
		<td align="left" valign="middle"><?php echo $empBasicReportData->mother_name ?></td>
		<td align="left" valign="middle"><strong>Nationality</strong> </td>
		<td align="center" valign="middle"><strong>:</strong></td>
		<td align="left" valign="middle"><?php echo $empBasicReportData->nationality_name ?></td>
	  </tr>
	  <tr>
		<td align="left" valign="middle"><strong>Branch</strong></td>
		<td align="center" valign="middle"><strong>:</strong></td>
		<td align="left" valign="middle"><?php echo $empBasicReportData->branch_name ?></td>
		<td align="left" valign="middle"><strong>Religion </strong></td>
		<td align="center" valign="middle"><strong>:</strong></td>
		<td align="left" valign="middle"><?php echo $empBasicReportData->religion_name ?></td>
	  </tr>
	  <tr>
		<td align="left" valign="middle"><strong>Zone</strong></td>
		<td align="center" valign="middle"><strong>:</strong></td>
		<td align="left" valign="middle"><?php echo $empBasicReportData->zone_name ?></td>
		<td align="left" valign="middle"><strong>Education Qualification</strong></td>
		<td align="center" valign="middle"><strong>:</strong></td>
		<td align="left" valign="middle"><?php echo $empBasicReportData->eduication_qualification ?></td>
	  </tr>
	  <tr>
		<td align="left" valign="middle"><strong>Department</strong> </td>
		<td align="center" valign="middle"><strong>:</strong></td>
		<td align="left" valign="middle"><?php echo $empBasicReportData->department_name ?></td>
		<td align="left" valign="middle"><strong>Area Of Exprience</strong></td>
		<td align="center" valign="middle"><strong>:</strong></td>
		<td align="left" valign="middle"><?php echo $empBasicReportData->area_of_exprience ?></td>
	  </tr>
	  <tr>
		<td align="left" valign="middle"><strong>Designition</strong></td>
		<td align="center" valign="middle"><strong>:</strong></td>
		<td align="left" valign="middle"><?php echo $empBasicReportData->designition_name ?></td>
		<td align="left" valign="middle"><strong>University/Institute</strong></td>
		<td align="center" valign="middle"><strong>:</strong></td>
		<td align="left" valign="middle"><?php echo $empBasicReportData->university_institute ?></td>
	  </tr>
	  <tr>
		<td align="left" valign="middle"><strong>Date of Birth</strong></td>
		<td align="center" valign="middle"><strong>:</strong></td>
		<td align="left" valign="middle"><?php echo $empBasicReportData->date_of_birth ?></td>
		<td align="left" valign="middle"><strong>Initial Joining Date</strong></td>
		<td align="center" valign="middle"><strong>:</strong></td>
		<td align="left" valign="middle"><?php echo $empBasicReportData->initiate_joining_date ?></td>
	  </tr>
	  <tr>
		<td align="left" valign="middle"><strong>Place Of Birth</strong></td>
		<td align="center" valign="middle"><strong>:</strong></td>
		<td align="left" valign="middle"><?php echo $empBasicReportData->place_name ?></td>
		<td align="left" valign="middle"><strong>Confirmation Date</strong></td>
		<td align="center" valign="middle"><strong>:</strong></td>
		<td align="left" valign="middle"><?php echo $empBasicReportData->confirmation_date ?></td>
	  </tr>
	  <tr>
		<td align="left" valign="middle"><strong>Mobile/Cell No</strong></td>
		<td align="center" valign="middle"><strong>:</strong></td>
		<td align="left" valign="middle"><?php echo $empBasicReportData->mobile_no ?></td>
		<td align="left" valign="middle"><strong>Appointment Date</strong> </td>
		<td align="center" valign="middle"><strong>:</strong></td>
		<td align="left" valign="middle"><?php echo $empBasicReportData->appointment_date ?></td>
	  </tr>
	  <tr>
		<td align="left" valign="middle"><strong>Phone No</strong></td>
		<td align="center" valign="middle"><strong>:</strong></td>
		<td align="left" valign="middle"><?php echo $empBasicReportData->phone_no ?></td>
		<td align="left" valign="middle"><strong>Initial Job Type</strong></td>
		<td align="center" valign="middle"><strong>:</strong></td>
		<td align="left" valign="middle"><?php echo $empBasicReportData->job_type_name ?></td>
	  </tr>
	  <tr>
		<td align="left" valign="middle"><strong>Email</strong></td>
		<td align="center" valign="middle"><strong>:</strong></td>
		<td align="left" valign="middle"><?php echo $empBasicReportData->email ?></td>
		<td align="left" valign="middle"><strong>Job Status</strong></td>
		<td align="center" valign="middle"><strong>:</strong></td>
		<td align="left" valign="middle"><?php if($empBasicReportData->job_status == 'inservice'){ echo "In Service"; }else if($empBasicReportData->job_status == 'notinservice'){ echo "Not In Service"; } ?></td>
	  </tr>
	  <tr>
		<td align="left" valign="middle"><strong>Present Address</strong></td>
		<td align="center" valign="middle"><strong>:</strong></td>
		<td align="left" valign="middle"><?php echo $empBasicReportData->present_address ?></td>
		<td align="left" valign="middle"><strong>Job Location</strong></td>
		<td align="center" valign="middle"><strong>:</strong></td>
		<td align="left" valign="middle"><?php echo $empBasicReportData->job_location ?></td>
	  </tr>
	  <tr>
		<td align="left" valign="middle"><strong>Permanent Address</strong></td>
		<td align="center" valign="middle"><strong>:</strong></td>
		<td align="left" valign="middle"><?php echo $empBasicReportData->permanent_address ?></td>
		<td><strong>Service length </strong></td>
		<td align="center" valign="middle"><strong>:</strong></td>
		<td align="left" valign="middle">
		   <?php 
		       if(!empty($empBasicReportData->initiate_joining_date)){ 
			    $today = date('Y-m-d');
			   
				$joiningDtae = new DateTime($empBasicReportData->initiate_joining_date);
				$currentDate = new DateTime($today);
				$diff = $joiningDtae->diff($currentDate);

				echo "Year : " . $diff->y . " Month : " . $diff->m." Days : ".$diff->d;
				 
			}

		 ?>
		</td>
	  </tr>
	   <tr>
		<td align="left" valign="middle"><strong>Shift</strong></td>
		<td align="center" valign="middle"><strong>:</strong></td>
		<td align="left" valign="middle"><?php echo $empBasicReportData->work_shift ?></td>
		<td align="left" valign="middle">&nbsp;</td>
		<td align="center" valign="middle">&nbsp;</td>
		<td align="left" valign="middle">&nbsp;</td>
	  </tr>
	</table>
	 
	</td>
  </tr>
  <?php if(!empty($empEssentialReportData)){ ?>
  <tr style="width: 100%;display: block; margin-top: 10px;">
    <td colspan="6" align="center" valign="middle" style="width: 100%;display: block;"><strong style="font-size:20px; text-decoration:underline">Employee Essential Information </strong> </td>
  </tr>
  <tr style="width: 100%;display: block">
    <td colspan="6" style="padding-left: 25px; width: 100%;display: block">
	   <table width="100%" border="0" style="line-height:30px;">
  <tr>
    <td width="24%" align="left" valign="middle"><strong>Bank Name</strong></td>
    <td width="3%" align="center" valign="middle"><strong>:</strong></td>
    <td width="23%" align="left" valign="middle"><?php echo $empEssentialReportData->bank_name ?></td>
    <td width="20%" align="left" valign="middle"><strong>Blood Group</strong></td>
    <td width="3%" align="center" valign="middle"><strong>:</strong></td>
    <td width="27%" align="left" valign="middle"><?php echo $empEssentialReportData->blood_group ?></td>
  </tr>
  <tr>
    <td align="left" valign="middle"><strong>Bank List</strong></td>
    <td align="center" valign="middle"><strong>:</strong></td>
    <td align="left" valign="middle"><?php echo $empEssentialReportData->bank_list ?></td>
    <td align="left" valign="middle"><strong>Driving Licence</strong></td>
    <td align="center" valign="middle"><strong>:</strong></td>
    <td align="left" valign="middle"><?php echo $empEssentialReportData->driving_licence ?></td>
  </tr>
  <tr>
    <td align="left" valign="middle"><strong>Branch</strong></td>
    <td align="center" valign="middle"><strong>:</strong></td>
    <td align="left" valign="middle"><?php echo $empEssentialReportData->branch_name ?></td>
    <td align="left" valign="middle"><strong>Type Of Licence</strong></td>
    <td align="center" valign="middle"><strong>:</strong></td>
    <td align="left" valign="middle"><?php echo $empEssentialReportData->type_of_licence ?></td>
  </tr>
  <tr>
    <td align="left" valign="middle"><strong>Address </strong></td>
    <td align="center" valign="middle"><strong>:</strong></td>
    <td align="left" valign="middle"><?php echo $empEssentialReportData->address ?></td>
    <td align="left" valign="middle"><strong>Passport </strong></td>
    <td align="center" valign="middle"><strong>:</strong></td>
    <td align="left" valign="middle"><?php echo $empEssentialReportData->passport_no ?></td>
  </tr>
  <tr>
    <td align="left" valign="middle"><strong>Account No</strong></td>
    <td align="center" valign="middle"><strong>:</strong></td>
    <td align="left" valign="middle"><?php echo $empEssentialReportData->account_no ?></td>
    <td align="left" valign="middle"><strong>Passport Issue Date</strong></td>
    <td align="center" valign="middle"><strong>:</strong></td>
    <td align="left" valign="middle"><?php echo $empEssentialReportData->passport_issu_date ?></td>
  </tr>
  <tr>
    <td align="left" valign="middle"><strong>Type Of Account</strong></td>
    <td align="center" valign="middle"><strong>:</strong></td>
    <td align="left" valign="middle"><?php echo $empEssentialReportData->type_of_account ?></td>
    <td align="left" valign="middle"><strong>Visited Country</strong></td>
    <td align="center" valign="middle"><strong>:</strong></td>
    <td align="left" valign="middle"><?php echo $empEssentialReportData->visited_country ?></td>
  </tr>
 
  <tr>
    <td align="left" valign="middle"><strong>NID </strong></td>
    <td align="center" valign="middle"><strong>:</strong></td>
    <td align="left" valign="middle"><?php echo $empEssentialReportData->nid ?></td>
    <td align="left" valign="middle"><strong>TIN </strong></td>
    <td align="center" valign="middle"><strong>:</strong></td>
    <td align="left" valign="middle"><?php echo $empEssentialReportData->tin ?></td>
  </tr>
  
</table>

	</td>
 </tr>
 
  <?php } ?>
  <tr>
    <td width="28%">&nbsp;</td>
    <td width="2%">&nbsp;</td>
    <td width="31%">&nbsp;</td>
    <td width="1%">&nbsp;</td>
    <td width="27%">&nbsp;</td>
    <td width="5%" align="center" valign="middle"><span style="color:#0000FF; font-weight:bold">Print</span></td>
  </tr>
 </tbody>
 
  
</table>


<div class="col-md-11 col-lg-11 col-sm-12 headerBox">
				<div class="row">
					<div class="col-md-2 col-sm-2 col-lg-2 leftBox paddingZero">
						<a class="logOut" > LogOut </a>
					</div>
					<div class="col-md-10 col-sm-10 col-lg-10 headerBox2">
						<div class="row ">
							<div class="col-md-3">
							&nbsp;
							</div>
						</div>	
					</div>
				</div>
				
				
				<div class="row">
					<div class="col-md-12 myFooter">
					<img src="<?php echo base_url('resource/interface/img/usoft.png'); ?>" class="pull-left img-responsive">
					<div class="text-right">� 2016 <a href="www.usoftbd.com" target="_blank">www.usoftbd.com</a></div>
				</div>
				</div>	
</div>

<?php $this->load->view('common/jsLinkPage'); ?>
<script type="text/javascript" >
setTimeout( "jQuery('#alertMsg').fadeOut();",8000 );

</script>

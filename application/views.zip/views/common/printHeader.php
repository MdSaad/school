<link rel="stylesheet" href="<?php echo base_url("resource/assets/css/bootstrap.min.css"); ?>" />
<link rel="stylesheet" href="<?php echo base_url("resource/css/animate.css"); ?>" />
<link rel="stylesheet" href="<?php echo base_url("resource/assets/font-awesome/4.2.0/css/font-awesome.min.css"); ?>" />
<link href="<?php echo base_url('resource/css/custom.css'); ?>" rel="stylesheet">

<link href="<?php echo base_url('resource/css/reportStyle.css'); ?>" rel="stylesheet" />
<div class="col-md-12">
			<div class="row text-center">
					<div><strong>Islami Academy School & College Trishal</strong></div>
					<div><strong>Main Campus </strong></div>
					<div><strong>Trishal, Mymensingh</strong></div>
			</div>
</div>
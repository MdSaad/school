<link rel="stylesheet" href="<?php echo base_url("resource/assets/css/bootstrap.min.css"); ?>" />
<link rel="stylesheet" href="<?php echo base_url("resource/css/animate.css"); ?>" />
<link rel="stylesheet" href="<?php echo base_url("resource/assets/font-awesome/4.2.0/css/font-awesome.min.css"); ?>" />
<link href="<?php echo base_url('resource/css/custom.css'); ?>" rel="stylesheet">

<link href="<?php echo base_url('resource/css/reportStyle.css'); ?>" rel="stylesheet" />
<div class="col-md-12">
			<div class="row">
					<div class="report_school_name text-center">Islami Academy School & College Trishal</div>
					<div class="report_school_name text-center">Main Campus </div>
					<div class="report_school_adrs text-center">Trishal, Mymensingh</div>
			</div>
</div>
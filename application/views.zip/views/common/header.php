<?php $this->load->view('common/cssLinkPage'); ?>
<script type="text/javascript" language="javascript" src="<?php echo site_url('adapter/javascript'); ?>"></script>

				<div class="row">
					<div class="col-md-2 col-sm-2 col-lg-2 leftBox paddingZero visible-lg visible-md visible-sm">
						<img src="<?php /*echo base_url('resource/interface/img/smscLogo.png'); */?>" class="img-responsive center-block" style="max-height:181px" />
					</div>
					<div class="col-md-10 col-sm-10 col-lg-10 middleContainer">
						<div class="row">
							<div class="col-md-12 col-sm-12">
								<div class="row text-center">
									<div class="col-md-12">
										<div class="">
											<div class="col-md-1" style="margin-top: 3%">
												<div class="thumbnail">
													<img src="<?php echo base_url('resource/interface/img/republic_of_bangladesh.jpg');?>"/>
												</div>
											</div>
											<div class="col-md-10">
												<div class="report_school_name text-center">VATTAPUR MODEL GOVT. PRIMARY SCHOOL <?php //echo $basicInfo->inst_name; ?></div>
												<div class="report_school_adrs text-center">Vill:-VATTAPUR, P.O: Sonargaon-1440, Word No.: 08, Sonargaon Paurashava </div>
												<div class="report_school_adrs text-center">Sonargaon Narayanganj </div>
												<div class="report_school_adrs text-center">Cell: 01959613022, Head Teacher: 01715010037 </div>
											</div>
											<div class="col-md-1" style="margin-top: 3%">
												<div class="thumbnail">
													<img src="<?php echo base_url('resource/interface/img/sober jonna mansommat shikhkha.jpg');?>" />
												</div>
											</div>
										</div>

									</div>
								</div>
							</div>
						</div>
					</div>
				</div>

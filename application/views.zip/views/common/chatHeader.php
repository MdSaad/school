<?php $this->load->view('common/cssLinkPage'); ?>
<script type="text/javascript" language="javascript" src="<?php echo site_url('adapter/javascript'); ?>"></script>
				<div class="row">
					<div class="col-md-2 col-sm-2 col-lg-2 leftBox paddingZero">
						<img src="<?php echo base_url('resource/interface/img/headerLeftImg.png'); ?>" class="img-responsive pull-right" style="max-height:270px" />
					</div>
					<div class="col-md-10 col-sm-10 col-lg-10 middleContainer">
						<!-- <div class="row school_name" style=""> S@ilor�s Model School & College</div>
						<div class="row school_adrs"> Majhira, Shajhahanpur, Bogra.</div>
						
						<div class="row erpTitle" style=""> S@ilor�s Model School & College</div> 
						<img src="<?php echo base_url('resource/interface/img/ok4.jpg'); ?>" class="" style="width: 100%" /> -->
						<div class="row">
							<div class="col-md-3 col-sm-3">
							<img src="<?php echo base_url('resource/interface/img/left2Img.png'); ?>" class="img-responsive pull-left" style="max-height:280px" />
							</div>
							
							
							<div class="col-md-6 col-sm-6">
								<div class="row">
										<img src="<?php echo base_url('resource/interface/img/smscLogo.png'); ?>" class="img-responsive center-block" style="height:80px" />
								</div>
								
								<div class="row brdrBottom">
										<div class="school_name text-center">Sayed Ahmed College</div>
										<div class="school_name text-center">Sukhanpukur</div>
										<div class="school_adrs text-center">Gabtoli, Bogra</div>
								</div>
								
								<div class="row">
										<div class="titleErp text-center">Usoftbd Academic ERP System</div>
								</div>
							</div>
							
							
							<div class="col-md-3 col-sm-3">
							<img src="<?php echo base_url('resource/interface/img/rightImg.png'); ?>" class="img-responsive pull-right" style="max-height:280px" />
							</div>
						</div>	
					</div>
				</div>
